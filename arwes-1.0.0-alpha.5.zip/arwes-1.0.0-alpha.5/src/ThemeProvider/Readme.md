Reference to the `<ThemeProvider />` solution for JSS apps at
[cssinjs/theming](https://github.com/cssinjs/theming).
