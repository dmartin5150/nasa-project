import { ThemeProvider } from 'theming';

export default ThemeProvider;
