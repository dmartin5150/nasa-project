import withStyles from '../tools/withStyles';
import Table from './Table';
import styles from './styles';

export default withStyles(styles)(Table);
