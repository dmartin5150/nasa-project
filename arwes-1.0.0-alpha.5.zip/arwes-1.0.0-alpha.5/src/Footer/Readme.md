A basic footer component. Not theme contomizable.

```javascript
<Footer animate>
    <p>Arwes details</p>
</Footer>
```
