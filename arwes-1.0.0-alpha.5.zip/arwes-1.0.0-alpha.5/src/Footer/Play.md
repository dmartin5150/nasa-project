```javascript
const resources = {
    bg: '/static/img/background.jpg',
    pattern: '/static/img/glow.png',
};
render(
    <Arwes resources={resources}>
        <div style={{ padding: 20 }}>
            <Footer animate>
                <p>Arwes details</p>
            </Footer>
        </div>
    </Arwes>
);
```
