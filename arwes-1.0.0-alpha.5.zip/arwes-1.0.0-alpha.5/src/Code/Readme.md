This is the replacement for code HTML tags. It works as inline `<code />` or
block `<pre />` tags.

```javascript
<Code animate>window.requestAnimationFrame(this.nextFrame);</Code>
```

The component uses [prismjs](http://prismjs.com) internally so if the component
is imported it is imported with it.
