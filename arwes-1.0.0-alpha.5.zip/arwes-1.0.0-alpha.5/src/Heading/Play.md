```javascript
render(
    <Arwes>
        <div style={{ margin: 20 }}>
            <Heading node='h1'>Futuristic Sci-Fi Interfaces</Heading>
            <Heading node='h2'>Futuristic Sci-Fi Interfaces</Heading>
            <Heading node='h3'>Futuristic Sci-Fi Interfaces</Heading>
            <Heading node='h4'>Futuristic Sci-Fi Interfaces</Heading>
            <Heading node='h5'>Futuristic Sci-Fi Interfaces</Heading>
            <Heading node='h6'>Futuristic Sci-Fi Interfaces</Heading>
        </div>
    </Arwes>
);
```
