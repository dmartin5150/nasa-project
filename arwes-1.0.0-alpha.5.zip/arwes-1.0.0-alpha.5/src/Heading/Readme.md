A heading HTML element.
