This is a wrapper to define animations in components. If the animations are not
enabled the children components should render as usual. This uses `react-transition-group`.
