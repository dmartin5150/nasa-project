import Animation from './Animation';

export default Animation;
