A list HTML element.
