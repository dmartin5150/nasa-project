```javascript
render(
    <Arwes>
        <div style={{ margin: 20 }}>
            <List node='ul'>
                <li>Futuristic</li>
                <li>Science Fiction</li>
                <li>Cyberpunk</li>
            </List>
            <List node='ol'>
                <li>Futuristic</li>
                <li>Science Fiction</li>
                <li>Cyberpunk</li>
            </List>
            <List node='dl'>
                <dt>Futuristic</dt>
                <dd>Science Fiction</dd>
                <dt>Futuristic</dt>
                <dd>Science Fiction</dd>
            </List>
        </div>
    </Arwes>
);
```
