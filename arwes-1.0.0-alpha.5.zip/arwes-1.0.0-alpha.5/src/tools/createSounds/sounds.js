export default {
  shared: {
    preload: true,
    volume: 0.5,
  },
  players: {},
};
