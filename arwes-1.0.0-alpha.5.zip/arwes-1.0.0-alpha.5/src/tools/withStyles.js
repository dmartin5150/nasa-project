import withStyles from 'react-jss/lib/injectSheet';

// Reference to the theming injection of sheets for JSS apps.
export default withStyles;
