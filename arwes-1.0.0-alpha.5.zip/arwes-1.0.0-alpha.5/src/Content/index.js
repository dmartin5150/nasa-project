import withStyles from '../tools/withStyles';
import Content from './Content';
import styles from './styles';

export default withStyles(styles)(Content);
