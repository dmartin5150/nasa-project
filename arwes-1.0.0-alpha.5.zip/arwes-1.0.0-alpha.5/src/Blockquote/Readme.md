A HTML `<blockquote />` element.
