```javascript
render(
    <Arwes>
        <div style={{ margin: 20 }}>
            <Blockquote>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Blockquote>

            <Blockquote data-layer='success'>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Blockquote>

            <Blockquote data-layer='alert'>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Blockquote>

            <Blockquote data-layer='disabled'>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Blockquote>
        </div>
    </Arwes>
);
```
