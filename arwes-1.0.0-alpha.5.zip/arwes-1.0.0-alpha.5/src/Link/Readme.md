A HTML `<a />` element.
