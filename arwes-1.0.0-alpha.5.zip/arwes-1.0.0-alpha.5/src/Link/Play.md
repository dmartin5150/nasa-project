```javascript
render(
    <Arwes>
        <div style={{ margin: 20 }}>
            This is an <Link href='#'>Intergalactic Link</Link>.
        </div>
    </Arwes>
);
```
