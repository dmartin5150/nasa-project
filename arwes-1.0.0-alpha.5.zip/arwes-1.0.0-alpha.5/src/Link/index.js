import withStyles from '../tools/withStyles';
import Link from './Link';
import styles from './styles';

export default withStyles(styles)(Link);
