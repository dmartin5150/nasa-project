```javascript
render(
    <Logo animate size={300} />
);
```
