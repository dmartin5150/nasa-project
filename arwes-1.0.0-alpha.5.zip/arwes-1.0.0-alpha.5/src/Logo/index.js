import withStyles from '../tools/withStyles';
import Logo from './Logo';
import styles from './styles';

export default withStyles(styles)(Logo);
