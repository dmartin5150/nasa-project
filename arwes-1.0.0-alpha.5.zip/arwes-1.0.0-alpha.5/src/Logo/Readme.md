The Arwes project logo.

```javascript
<Logo animate />
```
