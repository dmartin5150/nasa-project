import withStyles from '../tools/withStyles';
import Loading from './Loading';
import styles from './styles';

export default withStyles(styles)(Loading);
