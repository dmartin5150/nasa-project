A loading animation component to inform of a progress taking course. The component
can take full space of a positioned parent element or be as small to fit inside
content.

```javascript
<Loading animate />
```
