```javascript
render(
    <div>
        <Line animate />
        <Line animate layer='success' />
        <Line animate layer='alert' />
    </div>
);
```
