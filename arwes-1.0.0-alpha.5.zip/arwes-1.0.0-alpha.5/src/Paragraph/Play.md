```javascript
render(
    <Arwes>
        <div style={{ margin: 20 }}>
            <Paragraph>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Paragraph>
            <Paragraph>Futuristic Sci-Fi and Cyberpunk Graphical User Interface Framework for Web Apps</Paragraph>
        </div>
    </Arwes>
);
```
