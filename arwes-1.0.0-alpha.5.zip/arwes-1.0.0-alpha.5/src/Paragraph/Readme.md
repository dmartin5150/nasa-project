A HTML `<p />` element.
