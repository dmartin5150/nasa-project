```javascript
render(
    <Arwes>
        <h3><Words animate>A cyberpunk UI project</Words></h3>
        <p><Words animate>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, amet
        cupiditate laboriosam sunt libero aliquam, consequatur alias ducimus adipisci
        nesciunt odit? Odio tenetur et itaque suscipit atque officiis debitis qui.
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, amet
        cupiditate laboriosam sunt libero aliquam, consequatur alias ducimus adipisci
        nesciunt odit? Odio tenetur et itaque suscipit atque officiis debitis qui.
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, amet
        cupiditate laboriosam sunt libero aliquam, consequatur alias ducimus adipisci
        nesciunt odit? Odio tenetur et itaque suscipit atque officiis debitis qui.
        </Words></p>
        <p><Words animate layer='success'>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, amet
        cupiditate laboriosam sunt libero aliquam, consequatur alias ducimus adipisci
        nesciunt odit? Odio tenetur et itaque suscipit atque officiis debitis qui.
        </Words></p>
        <p><Words animate layer='alert'>With animations based on SciFi and designs from high technology</Words></p>
    </Arwes>
);
```
