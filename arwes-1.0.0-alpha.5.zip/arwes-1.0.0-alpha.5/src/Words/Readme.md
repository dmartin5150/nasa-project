A plain text wrapper component to apply styles and animation.

```javascript
<Words animate>Arwes is a cyberpunk UI framework</Words>
```

This component **does not** use the `<Animation />` component underneat.
