A basic header component. Not theme contomizable.

```javascript
<Header animate>
    <p>Arwes details</p>
</Header>
```
