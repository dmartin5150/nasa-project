```javascript
const resources = {
    bg: '/static/img/background.jpg',
    pattern: '/static/img/glow.png',
};
render(
    <Arwes resources={resources}>
        <div style={{ padding: 20 }}>
            <Header animate>
                <h1 style={{ margin: 0 }}>Arwes - Cyberpunk UI Framework</h1>
            </Header>
        </div>
    </Arwes>
);
```
