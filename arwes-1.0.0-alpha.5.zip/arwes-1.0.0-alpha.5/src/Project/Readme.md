This is like a card content component, used to display a content item, for example
an article, post or project. It uses the `<Frame />` component as a wrapper
and the `<Words />` for the header title animation.

```javascript
<Project animate header='Arwes'>
    Futuristic Sci-Fi and Cyberpunk Graphical
    User Interface Framework for Web Apps
</Project>
```

The theme is the primary and the title has the header theme, this is not configurable.
