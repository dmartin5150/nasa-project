```javascript
render(
    <Puffs>
        <div style={{ width: '100%', height: 500 }} />
    </Puffs>
);
```
