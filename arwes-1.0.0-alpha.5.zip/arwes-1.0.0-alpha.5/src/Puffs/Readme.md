An animation wrapper component. Creates a container with animated elements in
the background every provided time. The elements will move smoothly and disappear.

```javascript
<Puffs style={{ width: '100%', height: 300 }} />
```
