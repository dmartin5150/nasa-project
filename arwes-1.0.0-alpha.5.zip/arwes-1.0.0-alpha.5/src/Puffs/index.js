import withStyles from '../tools/withStyles';
import Puffs from './Puffs';
import styles from './styles';

export default withStyles(styles)(Puffs);
