import withStyles from '../tools/withStyles';
import Highlight from './Highlight';
import styles from './styles';

export default withStyles(styles)(Highlight);
