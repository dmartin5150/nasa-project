An animation wrapper component to add an `onClick` highlight animation in
the background.

```javascript
<Highlight layer='alert'>
    <div style={{ padding: '20px' }}>Arwes</div>
</Highlight>
```
