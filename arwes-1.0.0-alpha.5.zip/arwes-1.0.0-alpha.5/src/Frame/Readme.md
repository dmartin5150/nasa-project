This is a wrapper component for content components. This adds a frame border
and optional corners with a background to hold content.

```javascript
<Frame animate level={1} corners={3}>
    <p>An SciFi Project</p>
</Frame>
```
