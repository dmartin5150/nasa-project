import withStyles from '../tools/withStyles';
import Appear from './Appear';
import styles from './styles';

export default withStyles(styles)(Appear);
