A simple animation component to make something invisible or visible.

```javascript
<Appear animate>Something that appears or dissappears</Appear>
```
