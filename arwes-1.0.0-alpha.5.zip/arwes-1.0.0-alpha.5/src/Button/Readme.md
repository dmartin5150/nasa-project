Main user control action for the user.

```javascript
<Button animate layer='success'>Arwes</Button>
```
