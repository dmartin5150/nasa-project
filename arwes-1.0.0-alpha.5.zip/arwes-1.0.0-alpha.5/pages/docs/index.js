import withContent from '../../site/withContent';
import markdown from '../../site/docs/index.md';

export default withContent({ markdown });
