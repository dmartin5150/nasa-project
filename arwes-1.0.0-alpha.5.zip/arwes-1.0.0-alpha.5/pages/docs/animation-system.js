import withContent from '../../site/withContent';
import markdown from '../../site/docs/animation-system.md';

export default withContent({ markdown });
