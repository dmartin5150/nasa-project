import withContent from '../../site/withContent';
import markdown from '../../site/docs/player-tool.md';

export default withContent({ markdown });
