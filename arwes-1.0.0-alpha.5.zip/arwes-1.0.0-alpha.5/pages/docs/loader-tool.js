import withContent from '../../site/withContent';
import markdown from '../../site/docs/loader-tool.md';

export default withContent({ markdown });
