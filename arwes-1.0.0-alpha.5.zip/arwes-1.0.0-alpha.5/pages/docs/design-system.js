import withContent from '../../site/withContent';
import markdown from '../../site/docs/design-system.md';

export default withContent({ markdown });
