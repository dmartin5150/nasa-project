import withContent from '../../site/withContent';
import markdown from '../../site/docs/responsive-tool.md';

export default withContent({ markdown });
