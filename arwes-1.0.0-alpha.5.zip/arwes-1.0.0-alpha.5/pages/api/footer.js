import withApi from '../../site/withApi';
import component from '../../site/api-components/footer.json';

export default withApi({ component });
