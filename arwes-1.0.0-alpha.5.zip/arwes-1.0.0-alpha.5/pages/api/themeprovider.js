import withApi from '../../site/withApi';
import component from '../../site/api-components/themeprovider.json';

export default withApi({ component });
