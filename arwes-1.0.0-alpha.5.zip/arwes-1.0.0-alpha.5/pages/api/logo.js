import withApi from '../../site/withApi';
import component from '../../site/api-components/logo.json';

export default withApi({ component });
