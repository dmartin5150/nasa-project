import withApi from '../../site/withApi';
import component from '../../site/api-components/image.json';

export default withApi({ component });
