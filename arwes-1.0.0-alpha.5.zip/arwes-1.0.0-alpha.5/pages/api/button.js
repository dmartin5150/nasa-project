import withApi from '../../site/withApi';
import component from '../../site/api-components/button.json';

export default withApi({ component });
