import withApi from '../../site/withApi';
import component from '../../site/api-components/puffs.json';

export default withApi({ component });
