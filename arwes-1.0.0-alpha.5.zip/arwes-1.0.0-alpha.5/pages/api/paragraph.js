import withApi from '../../site/withApi';
import component from '../../site/api-components/paragraph.json';

export default withApi({ component });
