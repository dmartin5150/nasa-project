import withApi from '../../site/withApi';
import component from '../../site/api-components/words.json';

export default withApi({ component });
