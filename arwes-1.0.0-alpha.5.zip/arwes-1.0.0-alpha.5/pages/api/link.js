import withApi from '../../site/withApi';
import component from '../../site/api-components/link.json';

export default withApi({ component });
