import withApi from '../../site/withApi';
import component from '../../site/api-components/animation.json';

export default withApi({ component });
