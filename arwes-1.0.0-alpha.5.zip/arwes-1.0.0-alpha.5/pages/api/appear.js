import withApi from '../../site/withApi';
import component from '../../site/api-components/appear.json';

export default withApi({ component });
