import withApi from '../../site/withApi';
import component from '../../site/api-components/content.json';

export default withApi({ component });
