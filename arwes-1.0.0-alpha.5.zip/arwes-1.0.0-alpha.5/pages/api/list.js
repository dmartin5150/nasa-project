import withApi from '../../site/withApi';
import component from '../../site/api-components/list.json';

export default withApi({ component });
