import withApi from '../../site/withApi';
import component from '../../site/api-components/soundsprovider.json';

export default withApi({ component });
