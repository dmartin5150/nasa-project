import withApi from '../../site/withApi';
import component from '../../site/api-components/header.json';

export default withApi({ component });
