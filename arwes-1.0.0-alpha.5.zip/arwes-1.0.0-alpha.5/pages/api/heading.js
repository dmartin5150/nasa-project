import withApi from '../../site/withApi';
import component from '../../site/api-components/heading.json';

export default withApi({ component });
