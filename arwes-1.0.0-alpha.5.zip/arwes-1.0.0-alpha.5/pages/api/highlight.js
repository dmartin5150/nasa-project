import withApi from '../../site/withApi';
import component from '../../site/api-components/highlight.json';

export default withApi({ component });
