import sandboxes from '../play/sandboxes';

export default sandboxes;
